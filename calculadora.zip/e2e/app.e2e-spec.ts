import { AppPage } from './app.po';

describe('calculadora App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

});
